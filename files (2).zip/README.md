# Reattivo NPL — Piattaforma intelligente

Piattaforma web per la gestione di portafogli NPL (Non-Performing Loans) immobiliari italiani, con AI Agent specializzato integrato.

## File

| File | Descrizione |
|------|-------------|
| `index.html` | Pagina di login / landing |
| `app.html` | Applicazione principale |

## Funzionalità

- **Dashboard** — metriche portafoglio, mappa operazioni, activity AI live
- **Progetti** — gestione portafoglio NPL con filtri, ricerca, crea/elimina
- **Documenti** — upload reale, agenti AI (deduplicazione, estrai data, rinomina, categorizza)
- **NPL Expert Agent** — agente AI specializzato NPL con web search su dati reali italiani
- **Crediti** — sistema pay-per-use €0,010/credito, nessun abbonamento
- **Team & Permessi** — gestione ruoli e accessi

## AI Agent

L'agente NPL Expert è collegato direttamente all'agente Anthropic specializzato.  
Per i documenti usa Claude Sonnet 4 con analisi del contenuto reale dei file caricati.

## Come usare

1. Apri `index.html` nel browser
2. Clicca "Accedi" (demo libera)
3. L'agente NPL Expert è già attivo — vai su "Agente NPL" nella sidebar

## Deploy su GitHub Pages

1. Carica `index.html` e `app.html` nella root del repository
2. Vai su **Settings → Pages → Source: main branch / root**
3. Il sito sarà disponibile su `https://tuousername.github.io/nome-repo/`

> I due file devono stare nella stessa cartella per il collegamento login → app.
